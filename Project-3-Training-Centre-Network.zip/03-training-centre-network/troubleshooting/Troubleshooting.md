# Troubleshooting
## Actual problem: wrong DHCP gateway
A PC first received an address ending in .3 and a gateway of 0.0.0.0. The earlier DHCP screenshot showed two overlapping pools: CLASSROOM and serverPool. The learner removed CLASSROOM and corrected serverPool to start at 192.168.40.100, use mask 255.255.255.0, gateway 192.168.40.1, DNS 192.168.40.2 and 50 users. After selecting Static and then DHCP on the PC, it received .100 with the correct gateway and DNS. The other PCs received .101–.103.

## Practice scenario: new PC cannot get an address
This was a discussion exercise, not a fault injected into the saved project. Check cables and links, server power, DHCP service On and pool settings. Request DHCP again and inspect ipconfig /all. Existing PCs can keep working while their leases remain valid even if DHCP stops.

## Practice scenario: IP works but website name fails
Check the client's DNS address, the server DNS service and the training.test A record. Test name resolution, then open http://training.test.

## Useful commands
PC: ipconfig /all, ping 192.168.40.1, ping 192.168.40.2, nslookup training.test
Router: show ip interface brief
Leave a space between ipconfig and /all.
