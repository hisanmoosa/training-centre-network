# Project 3 — Training Centre Network
A Cisco Packet Tracer training lab with four student PCs, one switch, one router and one server. The server supplies DHCP, DNS and HTTP.

## Open the project
Open topology/Training-Centre-Network.pkt in Cisco Packet Tracer. View screenshots/Project-3-Network-Evidence.jpg for the combined evidence sheet. Read the Markdown (.md) and text (.txt) files in any text editor.

## What worked
- Four PCs received 192.168.40.100–103 with mask 255.255.255.0 and gateway 192.168.40.1.
- Pings to the gateway and server returned 4 replies from 4 requests.
- DNS resolved training.test to 192.168.40.2.
- The webpage opened by IP and by name; the learner reported success on all four PCs.

## Evidence and limits
The four original screenshots are included unchanged. Command panels are recreated excerpts from learner-pasted output, not screenshots. Test results are from the supplied evidence and learner reports; the supplied .pkt was preserved unchanged and was not independently run. Full Project 3 router/switch running-config exports were not supplied. The configuration folder contains reference settings, not claimed device exports. No internet connection or remote network is demonstrated.

## Folder guide
- topology: supplied Packet Tracer project
- screenshots: original screenshots and combined JPG
- addressing: IP address table
- configurations: server settings and reference router commands
- verification: results and command excerpts
- troubleshooting: actual DHCP correction and practice scenarios
- documentation: plain-English explanation and presentation notes
