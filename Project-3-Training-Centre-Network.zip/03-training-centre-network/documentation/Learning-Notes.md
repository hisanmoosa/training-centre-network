# Simple explanation
DHCP gives a PC its IP address, subnet mask, gateway and DNS server address automatically. A lease allows it to use the address for a period of time.

DNS finds the IP address for a name. Here training.test points to 192.168.40.2.

HTTP lets the browser request and receive the webpage. The same server runs all three services, so DHCP and DNS can show the same server IP.

## DHCP: DORA
1. Discover: the PC broadcasts to find a DHCP server.
2. Offer: the server offers an address and settings.
3. Request: the PC requests the offered address.
4. Acknowledge: the server confirms the lease.

## The switch and router
S1-TRAINING connects the PCs, server and router. Local devices in the same subnet communicate through the switch. The router provides the default gateway for reaching other networks. This project's server is local, so local DNS and website traffic do not need to pass through the router. A switch management IP is not needed for basic forwarding.

## Brief presentation
This is my training centre network. Four PCs connect to a switch, along with a server and a router. I configured DHCP to give the PCs addresses automatically. I added a DNS record for training.test and used HTTP to open the server's webpage. I checked the PC addresses, pinged the server and gateway, and tested the website by name. I corrected a DHCP pool problem that had given a PC the wrong gateway.
