# Verification results
| Test | Result | Evidence |
|---|---|---|
| Router G0/0 | 192.168.40.1, up/up | Pasted interface output |
| PC1 DHCP | .100, gateway .1, DNS .2, DHCP server .2 | Pasted ipconfig /all |
| Other PCs | .101, .102, .103, /24, gateway .1 | Pasted ipconfig |
| Gateway ping | 4/4 replies, 0% loss | Pasted ping |
| Server ping | 4/4 replies, 0% loss | Pasted ping |
| Name resolution | training.test -> 192.168.40.2 | Pasted DNS lookup and DNS screenshot |
| Webpage by IP | Default webpage displayed | Learner report |
| Webpage by name | Default webpage displayed | Browser screenshot; all four PCs confirmed by learner |

These are supplied results, not tests rerun by the document author.
